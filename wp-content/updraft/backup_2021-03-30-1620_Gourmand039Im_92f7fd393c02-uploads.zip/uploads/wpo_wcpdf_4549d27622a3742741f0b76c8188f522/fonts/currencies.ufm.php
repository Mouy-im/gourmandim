<?php return array (
  'codeToName' => 
  array (
    32 => 'space',
    65 => 'A',
    66 => 'B',
    67 => 'C',
    68 => 'D',
    69 => 'E',
    70 => 'F',
    71 => 'G',
    72 => 'H',
    73 => 'I',
    74 => 'J',
    75 => 'K',
    76 => 'L',
    77 => 'M',
    78 => 'N',
    79 => 'O',
    80 => 'P',
    81 => 'Q',
    82 => 'R',
    83 => 'S',
    84 => 'T',
    85 => 'U',
    86 => 'V',
    87 => 'W',
    88 => 'X',
    89 => 'Y',
    90 => 'Z',
    97 => 'a',
    98 => 'b',
    99 => 'c',
    100 => 'd',
    101 => 'e',
    102 => 'f',
    103 => 'g',
    104 => 'h',
    105 => 'i',
    106 => 'j',
    107 => 'k',
    108 => 'l',
    109 => 'm',
    110 => 'n',
    111 => 'o',
    112 => 'p',
    113 => 'q',
    114 => 'r',
    115 => 's',
    116 => 't',
    117 => 'u',
    118 => 'v',
    119 => 'w',
    120 => 'x',
    121 => 'y',
    122 => 'z',
  ),
  'isUnicode' => true,
  'EncodingScheme' => 'FontSpecific',
  'FontName' => 'Currencies',
  'FullName' => 'Currencies',
  'Version' => 'Version 1.171',
  'PostScriptName' => 'Currencies',
  'Weight' => 'Bold',
  'ItalicAngle' => '0',
  'IsFixedPitch' => 'false',
  'UnderlineThickness' => '50',
  'UnderlinePosition' => '-299',
  'FontHeightOffset' => '0',
  'Ascender' => '977',
  'Descender' => '-293',
  'FontBBox' => 
  array (
    0 => '-78',
    1 => '-293',
    2 => '1047',
    3 => '977',
  ),
  'StartCharMetrics' => '105',
  'C' => 
  array (
    32 => 391.0,
    36 => 514.0,
    65 => 633.0,
    66 => 648.0,
    67 => 631.0,
    68 => 729.0,
    69 => 556.0,
    70 => 516.0,
    71 => 728.0,
    72 => 738.0,
    73 => 279.0,
    74 => 267.0,
    75 => 614.0,
    76 => 519.0,
    77 => 903.0,
    78 => 754.0,
    79 => 779.0,
    80 => 602.0,
    81 => 779.0,
    82 => 618.0,
    83 => 549.0,
    84 => 553.0,
    85 => 728.0,
    86 => 595.0,
    87 => 926.0,
    88 => 577.0,
    89 => 560.0,
    90 => 571.0,
    97 => 556.0,
    98 => 613.0,
    99 => 476.0,
    100 => 613.0,
    101 => 561.0,
    102 => 339.0,
    103 => 548.0,
    104 => 614.0,
    105 => 253.0,
    106 => 253.0,
    107 => 525.0,
    108 => 253.0,
    109 => 930.0,
    110 => 614.0,
    111 => 604.0,
    112 => 613.0,
    113 => 613.0,
    114 => 408.0,
    115 => 477.0,
    116 => 353.0,
    117 => 614.0,
    118 => 501.0,
    119 => 778.0,
    120 => 524.0,
    121 => 504.0,
    122 => 468.0,
    160 => 391.0,
    162 => 475.0,
    163 => 693.0,
    164 => 703.0,
    165 => 604.0,
    402 => 563.0,
    2546 => 537.0,
    2547 => 611.0,
    2801 => 779.0,
    3065 => 1047.0,
    3647 => 703.0,
    4314 => 1064.0,
    6107 => 377.0,
    8199 => 391.0,
    8239 => 391.0,
    8288 => 391.0,
    8352 => 703.0,
    8353 => 650.0,
    8354 => 670.0,
    8355 => 586.0,
    8356 => 693.0,
    8357 => 967.0,
    8358 => 895.0,
    8359 => 764.0,
    8360 => 961.0,
    8361 => 1025.0,
    8362 => 736.0,
    8363 => 676.0,
    8364 => 746.0,
    8365 => 965.0,
    8366 => 633.0,
    8367 => 1049.0,
    8368 => 709.0,
    8369 => 881.0,
    8370 => 650.0,
    8371 => 760.0,
    8372 => 643.0,
    8373 => 650.0,
    8377 => 636.0,
    8378 => 636.0,
    8381 => 636.0,
    8382 => 572.0,
    8499 => 824.0,
    20803 => 1000.0,
    20870 => 1000.0,
    22278 => 1000.0,
    22291 => 1000.0,
    65020 => 1086.0,
  ),
  'CIDtoGID_Compressed' => true,
  'CIDtoGID' => 'eJztz2kzFlAcxuF7pn1PWhWFNlTKVqGFFlGiCEVpEb7/J8gYb8qomTyeQ13XzJnz4sz5n99JNmnX2r77ryfsyd7sy/4cyMEcyuEcydEcy/HU5ERqczKncjpncjbnUpfzuZD6NPx0/2IupTFNac7lXMnVXMv1tKQ1bbmRm7mV9tzOnXSkM13pTk/u5t4m/vur+yurN33pz4MKTmU7eVg6AAAAAOAPHuVx6QSKGSgdwLYyWDoAYMWT0gEAO8rT0gEAAABUybPSAQAAAMCO9bzC84YqPG+9F1v+wu8NZyQv8yqjeZ2xjOdN3mYik3mXqUxnJu/zIbOZy8d8Wrsxn8+r+5d8LVZdbd9KBwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwH9goXTAqu+lAwAAoIoWNzxZqmIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPx7lksHAKX9ALW8FVI=',
  '_version_' => 6,
);